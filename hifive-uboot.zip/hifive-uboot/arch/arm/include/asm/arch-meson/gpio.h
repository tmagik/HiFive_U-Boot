/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * (C) Copyright 2017 - Beniamino Galvani <b.galvani@gmail.com>
 */

#ifndef __ASM_ARCH_MESON_GPIO_H
#define __ASM_ARCH_MESON_GPIO_H


#endif	/* __ASM_ARCH_MESON_GPIO_H */
