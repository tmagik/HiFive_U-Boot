/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2013 Broadcom Corporation.
 */

#ifndef __ARCH_BCM281XX_GPIO_H
#define __ARCH_BCM281XX_GPIO_H

/*
 * Empty file - cmd_gpio.c requires this. The implementation
 * is in drivers/gpio/kona_gpio.c instead of inlined here.
 */

#endif
